import logo from './logo.svg';
import './App.css';

import 'bootstrap/dist/css/bootstrap.min.css';




import Home from './componts/Home';
import Work from './componts/Work';
import About from './componts/About';
import Blog from './componts/Blog';
import Contact from './componts/Contact';
import Services from './componts/Services';







function App() {
  return (
    <div>


     <Home/>
    <Work/>
    <Services/>
    <About/>
    <Blog/>
    <Contact/>
      {/* ********************work **************************/}
   






      {/* ***********************our services********************** */}

     


      {/* *****************about section********************** */}

     

      {/* ************blog******************* */}

   


      {/* *****************************contact****************** */}


    </div>



  );
}

export default App;
