import React from 'react'

function ExampleCarouselImage1() {
  return (
    <div>
        <img src={require('./img/laptop.png')} alt="" />
    </div>
  )
}

export default ExampleCarouselImage1