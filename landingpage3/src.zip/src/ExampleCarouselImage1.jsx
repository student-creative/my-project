import React from 'react'

function ExampleCarouselImage1() {
  return (
    <div>
        <img src="" alt="" />
    </div>
  )
}

export default ExampleCarouselImage1