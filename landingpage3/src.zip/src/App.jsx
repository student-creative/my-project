import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      <div className="navbar py-6 flex items-center justify-around">
        <h1 className='text-4xl px-3'>Create <span className='text-cyan-500'>.</span></h1>
        <div className="menubar">
          <ul className='flex space-x-16 font-thin'>
            <li className='hover:text-cyan-500'>Home</li>
            <li className='hover:text-cyan-500'>Work</li>
            <li className='hover:text-cyan-500'>Services</li>
            <li className='hover:text-cyan-500'>About</li>
            <li className='hover:text-cyan-500'>Blog</li>
            <li className='hover:text-cyan-500'>Contact</li>
          </ul>
        </div>
      </div>


      {/* ***********slider***************** */}


    <Carousel>
      <Carousel.Item interval={1000}>
        <ExampleCarouselImage text="First slide" />
        <Carousel.Caption>
          <h3>First slide label</h3>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={500}>
        <ExampleCarouselImage text="Second slide" />
        <Carousel.Caption>
          <h3>Second slide label</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <ExampleCarouselImage text="Third slide" />
        <Carousel.Caption>
          <h3>Third slide label</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
 

    </div>
  );
}

export default App;
