import React from 'react'
import Carousel from 'react-bootstrap/Carousel';
import ExampleCarouselImage1 from './ExampleCarouselImage1';
import ExampleCarouselImage2 from './ExampleCarouselImage2';
import ExampleCarouselImage3 from './ExampleCarouselImage3';
import 'bootstrap/dist/css/bootstrap.min.css';
import  Navbar  from './Navbar';

function Slider() {
  return (

    <div>
   <div className='relative w-full md:w-full'>
    <Carousel fade className="w-full h-screen">
      <Carousel.Item>
        <ExampleCarouselImage1 text="First slide" />
        <Carousel.Caption>

        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <ExampleCarouselImage2 text="Second slide" />
        <Carousel.Caption>

        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <ExampleCarouselImage3 text="Third slide" />
        <Carousel.Caption>

        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>

    <Navbar />


    {/* *************************************** */}
    
    <div className="absolute top-1/3 w-full flex flex-col items-center justify-center text-white z-10 px-4">
  <h2 className="capitalize text-yellow-600 text-base md:text-xl lg:text-2xl">We have been serving</h2>
  <h1 className="uppercase text-[60px] md:text-[100px] lg:text-[170px] leading-none font-bold">coffe</h1>
  <h2 className="text-sm md:text-lg m-0">* SINCE 1950 *</h2>
</div>

      
      </div>
  </div>
 
  )
}

export default Slider
