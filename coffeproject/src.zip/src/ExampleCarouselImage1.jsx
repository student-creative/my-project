import React from 'react'

function ExampleCarouselImage1() {
  return (
    <div>
        <div className="opacity-90 bg-black w-full h-screen object-cover">
      <img  className='img' src={require('./img/back1.jpg')} alt=""  />
    </div>
    </div>
  )
}

export default ExampleCarouselImage1
