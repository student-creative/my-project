import React from 'react'

function Navbar() {
  return (
    <div>
          <nav className="absolute flex items-center justify-between top-0 left-0 w-full text-white  z-10">
      <div className="mx-16">
      <h1 className="font-bold text-6xl">KOPPE</h1>
      </div>
      <ul className="flex space-x-20 font-bold">
        <li className='text-xl'>Home</li>
        <li className='text-xl'>About</li>
        <li className='text-xl'>Service</li>
        <li className='text-xl'>Menu</li>
        <li className='text-xl'>Pages</li>
      </ul>
    </nav>
    </div>
  )
}

export default Navbar
