import React from 'react';

function ExampleCarouselImage3() {
  return (
    <div className="w-full h-screen">
      <img
        src={require('./img/back3.jpg')}
        alt="Slide 3"
        className="w-full h-full object-cover"
      />
    </div>
  );
}

export default ExampleCarouselImage3;
