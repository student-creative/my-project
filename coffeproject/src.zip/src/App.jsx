
import Slider from './Slider';

function App() {
  return (
   <div>
    <Slider />
   </div>
  );
}

export default App;