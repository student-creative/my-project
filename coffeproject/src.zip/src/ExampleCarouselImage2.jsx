import React from 'react'

function ExampleCarouselImage2() {
  return (
    <div>
      <div className="opacity-90 bg-black w-full h-screen object-cover">
       <img  className='img' src={require('./img/back2.jpg')} alt="" />
       </div>
    </div>
  )
}

export default ExampleCarouselImage2
